KDocker
-------
KDocker will help you dock any application in the system tray. This means you
can dock openoffice, firefox, thunderbolt, eclipse, anything! Just point
and click. Works for both KDE and GNOME (In fact it should work for most modern
window managers that support NET WM Specification. I believe it works for XFCE,
for instance)

All you need to do is start KDocker and select an application using the mouse
and lo! the application gets docked into the system tray. The application can 
also be made to dissappear from the task bar.

System Tray Support
-------------------
KDocker supports the System Tray Protocol from freedesktop.org

Website
-------

https://github.com/user-none/KDocker

Reporting Bugs 
--------------
Bug tracker is at https://github.com/user-none/KDocker
